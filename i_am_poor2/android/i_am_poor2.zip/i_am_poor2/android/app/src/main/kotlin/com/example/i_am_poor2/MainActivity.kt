package com.example.i_am_poor2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
